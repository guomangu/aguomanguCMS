declare var SULU_ADMIN_BUILD_VERSION: string;
