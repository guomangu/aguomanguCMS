<?php

declare(strict_types=1);

/*
 * This file is part of Sulu.
 *
 * (c) Sulu GmbH
 *
 * This source file is subject to the MIT license that is bundled
 * with this source code in the file LICENSE.
 */

namespace Sulu\Content\Application\PropertyResolver\Resolver;

use Sulu\Bundle\MarkupBundle\Markup\Link\LinkItem;
use Sulu\Content\Application\ContentResolver\Value\ContentView;
use Sulu\Content\Application\ResourceLoader\Loader\LinkResourceLoader;

class LinkPropertyResolver implements PropertyResolverInterface
{
    public function resolve(mixed $data, string $locale, array $params = []): ContentView
    {
        if (
            !\is_array($data)
            || !\array_key_exists('href', $data)
            || !\array_key_exists('provider', $data)
            || !(\is_string($data['href']) || \is_integer($data['href']))
            || !\is_string($data['provider'])
        ) {
            return ContentView::create($data, [...$params]);
        }

        /** @var string $resourceLoaderKey */
        $resourceLoaderKey = $params['resourceLoader'] ?? LinkResourceLoader::getKey();

        return ContentView::createResolvable(
            id: $data['provider'] . '::' . $data['href'],
            resourceLoaderKey: $resourceLoaderKey,
            view: [
                ...$data,
                ...$params,
            ],
            priority: -50,
            // external links are not passed as a LinkItem
            closure: static function(LinkItem $linkItem) use ($data) {
                $url = $linkItem->getUrl();
                if (isset($data['query']) && \is_string($data['query'])) {
                    $url = \sprintf('%s?%s', $url, \ltrim($data['query'], '?'));
                }
                if (isset($data['anchor']) && \is_string($data['anchor'])) {
                    $url = \sprintf('%s#%s', $url, \ltrim($data['anchor'], '#'));
                }

                return $url;
            }
        );
    }

    public static function getType(): string
    {
        return 'link';
    }
}
