<?php

declare(strict_types=1);

/*
 * This file is part of Sulu.
 *
 * (c) Sulu GmbH
 *
 * This source file is subject to the MIT license that is bundled
 * with this source code in the file LICENSE.
 */

namespace Sulu\Content\Tests\Unit\Content\Application\ContentResolver\Resolver;

use PHPUnit\Framework\TestCase;
use Prophecy\PhpUnit\ProphecyTrait;
use Sulu\Bundle\AdminBundle\Metadata\FormMetadata\FieldMetadata;
use Sulu\Bundle\AdminBundle\Metadata\FormMetadata\FormMetadata;
use Sulu\Bundle\AdminBundle\Metadata\FormMetadata\TypedFormMetadata;
use Sulu\Bundle\AdminBundle\Metadata\MetadataProviderInterface;
use Sulu\Content\Application\ContentResolver\Resolver\TemplateResolver;
use Sulu\Content\Application\ContentResolver\Value\ContentView;
use Sulu\Content\Application\MetadataResolver\MetadataResolver;
use Sulu\Content\Application\PropertyResolver\PropertyResolverProvider;
use Sulu\Content\Application\PropertyResolver\Resolver\DefaultPropertyResolver;
use Sulu\Content\Domain\Model\DimensionContentInterface;
use Sulu\Content\Tests\Application\ExampleTestBundle\Entity\Example;
use Sulu\Content\Tests\Application\ExampleTestBundle\Entity\ExampleDimensionContent;

class TemplateResolverTest extends TestCase
{
    use ProphecyTrait;

    public function testResolveWithNonTemplateInterface(): void
    {
        $templateResolver = new TemplateResolver(
            $this->prophesize(MetadataProviderInterface::class)->reveal(),
            $this->prophesize(MetadataResolver::class)->reveal()
        );

        self::assertNull($templateResolver->resolve($this->prophesize(DimensionContentInterface::class)->reveal()));
    }

    public function testInvalidTemplateKeyResolve(): void
    {
        $example = new Example();
        $dimensionContent = new ExampleDimensionContent($example);
        $example->addDimensionContent($dimensionContent);
        $dimensionContent->setLocale('en');
        $dimensionContent->setTemplateKey('invalid');
        $dimensionContent->setTemplateData(['title' => 'Sulu']);

        $formMetadata = $this->prophesize(TypedFormMetadata::class);
        $formMetadata->getForms()
            ->willReturn([]);
        $formMetadataProvider = $this->prophesize(MetadataProviderInterface::class);
        $formMetadataProvider->getMetadata('example', 'en', [])
            ->willReturn($formMetadata->reveal());

        $templateResolver = new TemplateResolver(
            $formMetadataProvider->reveal(),
            $this->prophesize(MetadataResolver::class)->reveal()
        );

        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('Template with key "invalid" not found. Available keys: ');

        $templateResolver->resolve($dimensionContent);
    }

    public function testResolve(): void
    {
        $example = new Example();
        $dimensionContent = new ExampleDimensionContent($example);
        $example->addDimensionContent($dimensionContent);
        $dimensionContent->setLocale('en');
        $dimensionContent->setTemplateKey('default');
        $dimensionContent->setTemplateData(['title' => 'Sulu']);

        $formMetadata = new TypedFormMetadata();
        $defaultFormMetadata = new FormMetadata();
        $fieldMetadata = new FieldMetadata('title');
        $fieldMetadata->setType('text_line');
        $defaultFormMetadata->setItems(['title' => $fieldMetadata]);
        $formMetadata->addForm('default', $defaultFormMetadata);
        $formMetadataProvider = $this->prophesize(MetadataProviderInterface::class);
        $formMetadataProvider->getMetadata('example', 'en', [])
            ->willReturn($formMetadata);

        $metadataResolver = new MetadataResolver(
            new PropertyResolverProvider(
                new \ArrayIterator(['default' => new DefaultPropertyResolver()])
            )
        );

        $templateResolver = new TemplateResolver(
            $formMetadataProvider->reveal(),
            $metadataResolver
        );

        $contentView = $templateResolver->resolve($dimensionContent);
        self::assertInstanceOf(ContentView::class, $contentView);

        $content = $contentView->getContent();
        self::assertIsArray($content);
        self::assertCount(1, $content);
        self::assertInstanceOf(ContentView::class, $content['title']);
        self::assertSame('Sulu', $content['title']->getContent());
        self::assertSame([], $content['title']->getView());
    }
}
